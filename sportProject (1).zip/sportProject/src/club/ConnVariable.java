/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package club;

/**
 *
 * @author tmkds
 */
public class ConnVariable {
   public static final String username1 ="sql6482042";
   public static String password1="cBkTBHSFNH";
   static final String dataconn1 ="jdbc:mysql://sql6.freemysqlhosting.net:3306/sql6482042";
}
